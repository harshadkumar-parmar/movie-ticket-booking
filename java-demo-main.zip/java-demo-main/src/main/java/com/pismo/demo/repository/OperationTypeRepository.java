package com.pismo.demo.repository;

import org.springframework.data.repository.CrudRepository;

import com.pismo.demo.entity.OperationType;

public interface OperationTypeRepository extends CrudRepository<OperationType, Object> {

}
