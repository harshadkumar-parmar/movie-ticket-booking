package com.pismo.demo.repository;

import org.springframework.data.repository.CrudRepository;

import com.pismo.demo.entity.Transaction;

public interface TrasanctionRepository extends CrudRepository<Transaction, Object> {
    
}
