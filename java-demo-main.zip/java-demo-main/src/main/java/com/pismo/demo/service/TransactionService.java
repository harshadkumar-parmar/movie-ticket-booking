package com.pismo.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.stereotype.Service;

import com.pismo.demo.entity.Account;
import com.pismo.demo.entity.Transaction;
import com.pismo.demo.repository.AccountRepository;
import com.pismo.demo.repository.TrasanctionRepository;

@Service
public class TransactionService {
    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private TrasanctionRepository transactionRepository;

    public Transaction createTransaction(Transaction transaction) throws NotFoundException{
        Account account = accountRepository.findById(transaction.getAccount().getAccount_id()).orElseThrow(() -> new NotFoundException());
        transaction.setAccount(account);
        return transactionRepository.save(transaction);
    }
}